<?php
namespace Codeception\Module;

class CodeHelper extends \Codeception\Module
{
    // here you can define custom methods for CodeGuy
}
