<?php

namespace tests\_pages;

use yii\codeception\BasePage;

class AboutPage extends BasePage
{
    public $route = 'site/about';
}
