<?php

return [
    'adminEmail' => 'me@selimreza.com',
];
